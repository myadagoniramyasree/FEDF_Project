const express = require('express');
const cors    = require('cors');
const fs      = require('fs');
const path    = require('path');

const app  = express();
const PORT = 3000;
const DATA = path.join(__dirname, 'data');

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..')));

// ── Helper ────────────────────────────────────────
const read  = file => { try { return JSON.parse(fs.readFileSync(path.join(DATA,file),'utf8')); } catch { return []; } };
const write = (file, data) => fs.writeFileSync(path.join(DATA,file), JSON.stringify(data,null,2));
const genId = prefix => prefix + Date.now().toString().slice(-6);

// ── Seed data ─────────────────────────────────────
function seedData() {
  if (!fs.existsSync(DATA)) fs.mkdirSync(DATA, { recursive: true });

  const files = {
    'patients.json': [
      { id:'PAT001', name:'Arun Kumar',   age:45, gender:'Male',   ward:'Ward A', bed:'A-12', condition:'Diabetes Type 2', doctor:'Dr. Sharma', status:'active', admitDate:'2025-01-10' },
      { id:'PAT002', name:'Meena Devi',   age:62, gender:'Female', ward:'Ward B', bed:'B-05', condition:'Hypertension',    doctor:'Dr. Rao',    status:'active', admitDate:'2025-01-12' },
      { id:'PAT003', name:'Suresh Reddy', age:38, gender:'Male',   ward:'Ward A', bed:'A-08', condition:'Post Surgery',    doctor:'Dr. Patel',  status:'active', admitDate:'2025-01-08' },
    ],
    'dietary_profiles.json': [
      { id:'DP001', patientId:'PAT001', dietType:'Diabetic',    allergies:['Gluten'], restrictions:['High Sugar','High Fat'], caloricNeeds:1800, protein:80, carbs:200, fat:55, notes:'Avoid sugar' },
      { id:'DP002', patientId:'PAT002', dietType:'Low Sodium',  allergies:['Shellfish'], restrictions:['High Salt'], caloricNeeds:1600, protein:70, carbs:210, fat:45, notes:'Low sodium strict' },
      { id:'DP003', patientId:'PAT003', dietType:'High Protein',allergies:[], restrictions:['Spicy Foods'], caloricNeeds:2200, protein:120, carbs:240, fat:70, notes:'Post-op recovery' },
    ],
    'meals.json': [
      { id:'MEAL001', name:'Oatmeal with Fruits',    type:'Breakfast', calories:320, protein:12, carbs:58, fat:6,  dietTypes:['Diabetic','Low Sodium'], allergens:[] },
      { id:'MEAL002', name:'Idli with Sambar',        type:'Breakfast', calories:280, protein:10, carbs:52, fat:4,  dietTypes:['Diabetic','Renal'],      allergens:[] },
      { id:'MEAL003', name:'Brown Rice with Dal',     type:'Lunch',     calories:420, protein:18, carbs:78, fat:6,  dietTypes:['Diabetic','Low Sodium'], allergens:[] },
      { id:'MEAL004', name:'Grilled Chicken Salad',   type:'Lunch',     calories:380, protein:42, carbs:22, fat:12, dietTypes:['High Protein'],          allergens:[] },
      { id:'MEAL005', name:'Vegetable Soup',           type:'Dinner',    calories:220, protein:8,  carbs:38, fat:4,  dietTypes:['Low Sodium','Renal'],    allergens:[] },
      { id:'MEAL006', name:'Chapati with Sabzi',       type:'Dinner',    calories:360, protein:14, carbs:64, fat:8,  dietTypes:['Diabetic'],              allergens:['Gluten'] },
    ],
    'meal_plans.json':     [],
    'kitchen_orders.json': [],
    'notifications.json':  [],
    'history.json':        [],
    'users.json': [
      { id:'ADMIN01',  name:'Dr. Admin',       email:'admin@hospital.com',  password:'admin123',    role:'admin' },
      { id:'DIET001',  name:'Dietitian Ravi',  email:'ravi@hospital.com',   password:'diet123',     role:'dietitian' },
      { id:'NRS001',   name:'Nurse Priya',     email:'priya@hospital.com',  password:'nurse123',    role:'nurse' },
      { id:'KIT001',   name:'Chef Kumar',      email:'kumar@hospital.com',  password:'kitchen123',  role:'kitchen' },
    ],
  };

  Object.entries(files).forEach(([file, data]) => {
    if (!fs.existsSync(path.join(DATA, file)))
      write(file, data);
  });
}
seedData();

// ════════════════════════════════════════════════════
// AUTH
// ════════════════════════════════════════════════════
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const users = read('users.json');
  const user  = users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const { password: _, ...safe } = user;
  res.json({ success: true, user: safe });
});

// ════════════════════════════════════════════════════
// PATIENTS
// ════════════════════════════════════════════════════
app.get('/api/patients', (req, res) => {
  let patients = read('patients.json');
  if (req.query.status) patients = patients.filter(p => p.status === req.query.status);
  res.json(patients);
});

app.post('/api/patients', (req, res) => {
  const patients = read('patients.json');
  const patient  = { id: genId('PAT'), ...req.body };
  patients.push(patient);
  write('patients.json', patients);
  res.json({ success: true, patient });
});

app.put('/api/patients/:id', (req, res) => {
  const patients = read('patients.json');
  const idx = patients.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  patients[idx] = { ...patients[idx], ...req.body };
  write('patients.json', patients);
  res.json({ success: true, patient: patients[idx] });
});

app.delete('/api/patients/:id', (req, res) => {
  let patients = read('patients.json');
  patients = patients.filter(p => p.id !== req.params.id);
  write('patients.json', patients);
  res.json({ success: true });
});

// ════════════════════════════════════════════════════
// DIETARY PROFILES
// ════════════════════════════════════════════════════
app.get('/api/dietary-profiles', (req, res) => {
  let profiles = read('dietary_profiles.json');
  if (req.query.patientId) profiles = profiles.filter(d => d.patientId === req.query.patientId);
  res.json(profiles);
});

app.post('/api/dietary-profiles', (req, res) => {
  const profiles = read('dietary_profiles.json');
  const profile  = { id: genId('DP'), ...req.body, createdAt: new Date().toISOString() };
  profiles.push(profile);
  write('dietary_profiles.json', profiles);
  res.json({ success: true, profile });
});

app.put('/api/dietary-profiles/:id', (req, res) => {
  const profiles = read('dietary_profiles.json');
  const idx = profiles.findIndex(d => d.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  profiles[idx] = { ...profiles[idx], ...req.body };
  write('dietary_profiles.json', profiles);
  res.json({ success: true });
});

app.delete('/api/dietary-profiles/:id', (req, res) => {
  let profiles = read('dietary_profiles.json');
  profiles = profiles.filter(d => d.id !== req.params.id);
  write('dietary_profiles.json', profiles);
  res.json({ success: true });
});

// ════════════════════════════════════════════════════
// MEALS
// ════════════════════════════════════════════════════
app.get('/api/meals', (req, res) => {
  let meals = read('meals.json');
  if (req.query.type)     meals = meals.filter(m => m.type === req.query.type);
  if (req.query.dietType) meals = meals.filter(m => m.dietTypes.includes(req.query.dietType));
  res.json(meals);
});

app.post('/api/meals', (req, res) => {
  const meals = read('meals.json');
  const meal  = { id: genId('MEAL'), ...req.body, available: true };
  meals.push(meal);
  write('meals.json', meals);
  res.json({ success: true, meal });
});

app.put('/api/meals/:id', (req, res) => {
  const meals = read('meals.json');
  const idx = meals.findIndex(m => m.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  meals[idx] = { ...meals[idx], ...req.body };
  write('meals.json', meals);
  res.json({ success: true });
});

app.delete('/api/meals/:id', (req, res) => {
  let meals = read('meals.json');
  meals = meals.filter(m => m.id !== req.params.id);
  write('meals.json', meals);
  res.json({ success: true });
});

// ════════════════════════════════════════════════════
// MEAL PLANS
// ════════════════════════════════════════════════════
app.get('/api/meal-plans', (req, res) => {
  let plans = read('meal_plans.json');
  if (req.query.patientId) plans = plans.filter(p => p.patientId === req.query.patientId);
  if (req.query.status)    plans = plans.filter(p => p.status === req.query.status);
  if (req.query.date)      plans = plans.filter(p => p.date === req.query.date);
  res.json(plans);
});

app.post('/api/meal-plans', (req, res) => {
  const plans = read('meal_plans.json');
  const plan  = { id: genId('MP'), status: 'pending', ...req.body, createdAt: new Date().toISOString() };
  plans.push(plan);
  write('meal_plans.json', plans);

  // Auto-create kitchen orders
  const orders  = read('kitchen_orders.json');
  const patients = read('patients.json');
  const patient  = patients.find(p => p.id === plan.patientId);
  const meals   = read('meals.json');
  const mealMap = { breakfast:'Breakfast', morningSnack:'Morning Snack', lunch:'Lunch', eveningSnack:'Evening Snack', dinner:'Dinner' };

  Object.entries(mealMap).forEach(([key, label]) => {
    if (plan[key]) {
      const meal = meals.find(m => m.id === plan[key]);
      orders.push({
        id: genId('KO'), planId: plan.id,
        patientId: plan.patientId, date: plan.date,
        mealTime: label, mealId: plan[key],
        mealName: meal?.name || '',
        ward: patient?.ward || '', bed: patient?.bed || '',
        status: 'pending', notes: '',
        createdAt: new Date().toISOString(), deliveredAt: ''
      });
    }
  });
  write('kitchen_orders.json', orders);
  res.json({ success: true, plan });
});

app.put('/api/meal-plans/:id', (req, res) => {
  const plans = read('meal_plans.json');
  const idx = plans.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  plans[idx] = { ...plans[idx], ...req.body };
  write('meal_plans.json', plans);
  res.json({ success: true });
});

// ════════════════════════════════════════════════════
// KITCHEN ORDERS
// ════════════════════════════════════════════════════
app.get('/api/kitchen-orders', (req, res) => {
  let orders = read('kitchen_orders.json');
  if (req.query.date)   orders = orders.filter(o => o.date === req.query.date);
  if (req.query.status) orders = orders.filter(o => o.status === req.query.status);
  if (req.query.ward)   orders = orders.filter(o => o.ward === req.query.ward);
  res.json(orders);
});

app.put('/api/kitchen-orders/:id', (req, res) => {
  const orders = read('kitchen_orders.json');
  const idx = orders.findIndex(o => o.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  orders[idx] = { ...orders[idx], ...req.body };
  if (req.body.status === 'delivered') orders[idx].deliveredAt = new Date().toISOString();
  write('kitchen_orders.json', orders);
  res.json({ success: true });
});

// ════════════════════════════════════════════════════
// ALLERGY CHECK
// ════════════════════════════════════════════════════
app.get('/api/allergy-check', (req, res) => {
  const { patientId, mealId } = req.query;
  const profiles = read('dietary_profiles.json');
  const meals    = read('meals.json');
  const profile  = profiles.find(d => d.patientId === patientId);
  const meal     = meals.find(m => m.id === mealId);
  if (!profile || !meal) return res.status(404).json({ error: 'Not found' });
  const conflicts = meal.allergens.filter(a => profile.allergies.includes(a));
  res.json({
    safe: conflicts.length === 0,
    conflicts,
    patientAllergies: profile.allergies,
    mealAllergens: meal.allergens,
    suitable: meal.dietTypes.includes(profile.dietType)
  });
});

// ════════════════════════════════════════════════════
// NOTIFICATIONS
// ════════════════════════════════════════════════════
app.get('/api/notifications', (req, res) => res.json(read('notifications.json')));

app.post('/api/notifications', (req, res) => {
  const notifs = read('notifications.json');
  notifs.unshift({ id: genId('N'), read: false, createdAt: new Date().toISOString(), ...req.body });
  write('notifications.json', notifs);
  res.json({ success: true });
});

app.put('/api/notifications/:id/read', (req, res) => {
  const notifs = read('notifications.json');
  const idx = notifs.findIndex(n => n.id === req.params.id);
  if (idx > -1) notifs[idx].read = true;
  write('notifications.json', notifs);
  res.json({ success: true });
});

// ════════════════════════════════════════════════════
// HISTORY
// ════════════════════════════════════════════════════
app.get('/api/history', (req, res) => res.json(read('history.json')));

app.post('/api/history', (req, res) => {
  const hist = read('history.json');
  hist.unshift({ id: genId('H'), createdAt: new Date().toISOString(), ...req.body });
  write('history.json', hist.slice(0, 500));
  res.json({ success: true });
});

// ════════════════════════════════════════════════════
// USERS (admin only)
// ════════════════════════════════════════════════════
app.get('/api/users', (req, res) => {
  const users = read('users.json').map(({ password, ...u }) => u);
  res.json(users);
});

app.post('/api/users', (req, res) => {
  const users = read('users.json');
  const user  = { id: genId('USR'), ...req.body };
  users.push(user);
  write('users.json', users);
  res.json({ success: true });
});

app.delete('/api/users/:id', (req, res) => {
  let users = read('users.json');
  users = users.filter(u => u.id !== req.params.id);
  write('users.json', users);
  res.json({ success: true });
});

// ════════════════════════════════════════════════════
// DASHBOARD STATS
// ════════════════════════════════════════════════════
app.get('/api/dashboard', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  res.json({
    totalPatients:   read('patients.json').filter(p => p.status === 'active').length,
    pendingApprovals:read('meal_plans.json').filter(p => p.status === 'pending').length,
    todayOrders:     read('kitchen_orders.json').filter(o => o.date === today).length,
    deliveredToday:  read('kitchen_orders.json').filter(o => o.date === today && o.status === 'delivered').length,
    allergyPatients: read('dietary_profiles.json').filter(d => d.allergies && d.allergies.length > 0).length,
    totalMeals:      read('meals.json').length,
  });
});

// ── Start ─────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🏥 HIMPS Backend running at http://localhost:${PORT}`);
  console.log(`📂 Open: http://localhost:${PORT}/index.html\n`);
});
