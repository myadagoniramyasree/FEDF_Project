/* ── DB Module ─────────────────────────────────── */
const DB = (() => {
  const get = k => { try { return JSON.parse(localStorage.getItem('himps_' + k)) || null; } catch { return null; } };
  const set = (k, v) => localStorage.setItem('himps_' + k, JSON.stringify(v));
  const del = k => localStorage.removeItem('himps_' + k);

  const seed = () => {
    if (get('seeded')) return;
    set('users', [
      { id:'ADMIN01',  name:'Dr. Admin',      email:'admin@hospital.com', password:'admin123',   role:'admin',      dept:'Administration' },
      { id:'NRS001',   name:'Nurse Priya',    email:'priya@hospital.com', password:'nurse123',   role:'nurse',      dept:'Ward A' },
      { id:'DIET001',  name:'Dietitian Ravi', email:'ravi@hospital.com',  password:'diet123',    role:'dietitian',  dept:'Nutrition' },
      { id:'KIT001',   name:'Chef Kumar',     email:'kumar@hospital.com', password:'kitchen123', role:'kitchen',    dept:'Kitchen' },
    ]);
    set('patients', [
      { id:'PAT001', name:'Arun Kumar',   age:45, gender:'Male',   ward:'Ward A', bed:'A-12', phone:'9876543210', admitDate:'2025-01-10', condition:'Diabetes Type 2',  doctor:'Dr. Sharma', status:'active' },
      { id:'PAT002', name:'Meena Devi',   age:62, gender:'Female', ward:'Ward B', bed:'B-05', phone:'9871234567', admitDate:'2025-01-12', condition:'Hypertension',     doctor:'Dr. Rao',    status:'active' },
      { id:'PAT003', name:'Suresh Reddy', age:38, gender:'Male',   ward:'Ward A', bed:'A-08', phone:'9812345678', admitDate:'2025-01-08', condition:'Post Surgery',     doctor:'Dr. Patel',  status:'active' },
      { id:'PAT004', name:'Lakshmi Bai',  age:55, gender:'Female', ward:'Ward C', bed:'C-03', phone:'9823456789', admitDate:'2025-01-15', condition:'Kidney Disease',   doctor:'Dr. Rao',    status:'active' },
    ]);
    set('dietary_profiles', [
      { id:'DP001', patientId:'PAT001', dietType:'Diabetic',     allergies:['Gluten'],      restrictions:['High Sugar','High Fat'],              caloricNeeds:1800, protein:80,  carbs:200, fat:55, waterIntake:2.5, notes:'Avoid sugary foods', createdAt:new Date().toISOString() },
      { id:'DP002', patientId:'PAT002', dietType:'Low Sodium',   allergies:['Shellfish'],   restrictions:['High Salt','Fried Foods'],            caloricNeeds:1600, protein:70,  carbs:210, fat:45, waterIntake:2.0, notes:'Strict low sodium',  createdAt:new Date().toISOString() },
      { id:'DP003', patientId:'PAT003', dietType:'High Protein', allergies:[],              restrictions:['Spicy Foods'],                        caloricNeeds:2200, protein:120, carbs:240, fat:70, waterIntake:3.0, notes:'Post-op recovery',    createdAt:new Date().toISOString() },
      { id:'DP004', patientId:'PAT004', dietType:'Renal',        allergies:['Nuts'],        restrictions:['High Potassium','High Phosphorus'],   caloricNeeds:1700, protein:50,  carbs:230, fat:55, waterIntake:1.5, notes:'Strict renal diet',   createdAt:new Date().toISOString() },
    ]);
    set('meals', [
      { id:'MEAL001', name:'Oatmeal with Fruits',     type:'Breakfast', calories:320, protein:12, carbs:58, fat:6,  dietTypes:['Diabetic','Low Sodium'],    allergens:[],       available:true },
      { id:'MEAL002', name:'Idli with Sambar',         type:'Breakfast', calories:280, protein:10, carbs:52, fat:4,  dietTypes:['Diabetic','Renal'],         allergens:[],       available:true },
      { id:'MEAL003', name:'Egg White Omelette',       type:'Breakfast', calories:180, protein:24, carbs:4,  fat:6,  dietTypes:['High Protein'],             allergens:['Eggs'], available:true },
      { id:'MEAL004', name:'Brown Rice with Dal',      type:'Lunch',     calories:420, protein:18, carbs:78, fat:6,  dietTypes:['Diabetic','Low Sodium'],    allergens:[],       available:true },
      { id:'MEAL005', name:'Grilled Chicken Salad',    type:'Lunch',     calories:380, protein:42, carbs:22, fat:12, dietTypes:['High Protein'],             allergens:[],       available:true },
      { id:'MEAL006', name:'Steamed Vegetables',       type:'Lunch',     calories:180, protein:6,  carbs:32, fat:2,  dietTypes:['Renal','Low Sodium'],       allergens:[],       available:true },
      { id:'MEAL007', name:'Fruit Bowl',               type:'Snack',     calories:150, protein:2,  carbs:36, fat:1,  dietTypes:['Diabetic','General'],       allergens:[],       available:true },
      { id:'MEAL008', name:'Vegetable Soup',           type:'Dinner',    calories:220, protein:8,  carbs:38, fat:4,  dietTypes:['Low Sodium','Renal'],       allergens:[],       available:true },
      { id:'MEAL009', name:'Chapati with Sabzi',        type:'Dinner',    calories:360, protein:14, carbs:64, fat:8,  dietTypes:['Diabetic','Low Sodium'],   allergens:['Gluten'],available:true },
      { id:'MEAL010', name:'Paneer Tikka (Low Fat)',   type:'Dinner',    calories:310, protein:28, carbs:18, fat:14, dietTypes:['High Protein'],             allergens:['Dairy'],available:true },
    ]);
    set('meal_plans',     []);
    set('kitchen_orders', []);
    set('notifications',  [
      { id:'N001', type:'allergy',  message:'PAT001 Arun Kumar has Gluten allergy — check before serving.', read:false, createdAt:new Date().toISOString() },
      { id:'N002', type:'approval', message:'Meal plan for PAT002 Meena Devi is pending approval.',          read:false, createdAt:new Date().toISOString() },
    ]);
    set('history', []);
    set('seeded', true);
  };
  return { get, set, del, seed };
})();

/* ── Auth Module ───────────────────────────────── */
const Auth = (() => {
  const login = (email, password) => {
    const users = DB.get('users') || [];
    const user = users.find(u => u.email === email && u.password === password);
    if (user) { DB.set('session', user); return user; }
    return null;
  };
  // FIX: logout goes to login.html (same folder as pages)
  const logout = () => {
    DB.del('session');
    window.location.href = 'login.html';
  };
  const session   = () => DB.get('session');
  const guard     = () => { if (!session()) window.location.href = 'login.html'; };
  const adminOnly = () => {
    const s = session();
    if (!s || s.role !== 'admin') { alert('Admin access only'); window.location.href = 'dashboard.html'; }
  };
  const hasRole = (...roles) => { const s = session(); return s && roles.includes(s.role); };
  return { login, logout, session, guard, adminOnly, hasRole };
})();

/* ── Utils ─────────────────────────────────────── */
const Utils = (() => {
  const genId     = prefix => prefix + Date.now().toString().slice(-6);
  const formatDate = d => d ? new Date(d).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' }) : '-';
  const formatTime = d => d ? new Date(d).toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' }) : '-';
  const today     = () => new Date().toISOString().split('T')[0];

  const toast = (msg, type = 'success') => {
    let c = document.getElementById('toast-container');
    if (!c) { c = document.createElement('div'); c.id = 'toast-container'; document.body.appendChild(c); }
    const icons = { success:'✅', error:'❌', warning:'⚠️', info:'ℹ️' };
    const t = document.createElement('div');
    t.className = 'toast ' + type;
    t.innerHTML = '<span>' + (icons[type]||'ℹ️') + '</span><span>' + msg + '</span>';
    c.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  };

  const modal = (id, show) => {
    const el = document.getElementById(id);
    if (el) el.style.display = show ? 'flex' : 'none';
  };

  const confirm = (msg, cb) => { if (window.confirm(msg)) cb(); };

  const logHistory = (action, details) => {
    const hist = DB.get('history') || [];
    const s = Auth.session();
    hist.unshift({ id: genId('H'), action, details, userId: s ? s.id : '', userName: s ? s.name : '', role: s ? s.role : '', createdAt: new Date().toISOString() });
    DB.set('history', hist.slice(0, 500));
  };

  const addNotification = (type, message) => {
    const notifs = DB.get('notifications') || [];
    notifs.unshift({ id: genId('N'), type, message, read: false, createdAt: new Date().toISOString() });
    DB.set('notifications', notifs);
  };

  const unreadCount = () => (DB.get('notifications') || []).filter(n => !n.read).length;

  const statusBadge = s => {
    const map = { pending:'badge-amber', approved:'badge-green', rejected:'badge-red', preparing:'badge-violet', delivered:'badge-teal', cancelled:'badge-gray' };
    return '<span class="badge ' + (map[s] || 'badge-gray') + '">' + s + '</span>';
  };

  const roleBadge = r => {
    const map = { admin:'badge-violet', dietitian:'badge-blue', nurse:'badge-green', kitchen:'badge-amber' };
    return '<span class="badge ' + (map[r] || 'badge-gray') + '">' + r + '</span>';
  };

  return { genId, formatDate, formatTime, today, toast, modal, confirm, logHistory, addNotification, unreadCount, statusBadge, roleBadge };
})();
