function renderSidebar(activePage) {
  Auth.guard();
  const user   = Auth.session();
  const unread = Utils.unreadCount();

  const allLinks = [
    { label:'MAIN', items:[
      { page:'dashboard',     icon:'🏠', label:'Dashboard',       roles:['admin','dietitian','nurse','kitchen'] },
    ]},
    { label:'PATIENTS', items:[
      { page:'patients',      icon:'🛏️',  label:'Patients',        roles:['admin','dietitian','nurse'] },
      { page:'dietary',       icon:'📋', label:'Dietary Profiles', roles:['admin','dietitian','nurse'] },
    ]},
    { label:'MEAL MANAGEMENT', items:[
      { page:'meals',         icon:'🍽️', label:'Meal Library',    roles:['admin','dietitian'] },
      { page:'planner',       icon:'📅', label:'Meal Planner',    roles:['admin','dietitian'] },
      { page:'allergy',       icon:'⚠️',  label:'Allergy Check',  roles:['admin','dietitian','nurse'] },
      { page:'calorie',       icon:'🔥', label:'Calorie Calc',    roles:['admin','dietitian'] },
    ]},
    { label:'KITCHEN', items:[
      { page:'kitchen',       icon:'👨‍🍳', label:'Kitchen Orders', roles:['admin','kitchen','nurse'] },
      { page:'approvals',     icon:'✅', label:'Approvals',        roles:['admin','dietitian'] },
    ]},
    { label:'REPORTS', items:[
      { page:'history',       icon:'📜', label:'History',          roles:['admin','dietitian'] },
      { page:'export',        icon:'📤', label:'Export',           roles:['admin'] },
      { page:'notifications', icon:'🔔', label:'Notifications',    roles:['admin','dietitian','nurse','kitchen'] },
    ]},
    { label:'ADMIN', items:[
      { page:'admin',         icon:'⚙️',  label:'Admin Panel',    roles:['admin'] },
    ]},
  ];

  const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0,2);

  let navHtml = '';
  allLinks.forEach(function(section) {
    const visible = section.items.filter(i => i.roles.includes(user.role));
    if (!visible.length) return;
    navHtml += '<div class="nav-section">' + section.label + '</div>';
    visible.forEach(function(item) {
      const isActive  = activePage === item.page ? 'active' : '';
      const badgeHtml = (item.page === 'notifications' && unread > 0)
        ? '<span class="nav-badge">' + unread + '</span>' : '';
      navHtml += '<div class="nav-item ' + isActive + '" onclick="location.href=\'' + item.page + '.html\'">'
        + '<span class="nav-icon">' + item.icon + '</span>'
        + '<span>' + item.label + '</span>'
        + badgeHtml
        + '</div>';
    });
  });

  const html =
    '<div class="sidebar-brand">' +
      '<div class="brand-logo">' +
        '<div class="brand-icon">🏥</div>' +
        '<div><div class="brand-name">HIMPS</div><div class="brand-sub">Hospital Meal Planning</div></div>' +
      '</div>' +
    '</div>' +
    '<div class="sidebar-user">' +
      '<div class="user-avatar">' + initials + '</div>' +
      '<div><div class="user-name">' + user.name + '</div><div class="user-role">' + user.role + '</div></div>' +
    '</div>' +
    '<nav class="sidebar-nav">' + navHtml + '</nav>' +
    '<div class="sidebar-footer">' +
      '<div class="nav-item" onclick="Auth.logout()">' +
        '<span class="nav-icon">🚪</span><span>Logout</span>' +
      '</div>' +
    '</div>';

  const el = document.getElementById('sidebar');
  if (el) el.innerHTML = html;

  const titleEl = document.getElementById('page-title-top');
  if (titleEl) {
    const cur = allLinks.flatMap(s => s.items).find(i => i.page === activePage);
    if (cur) titleEl.textContent = cur.label;
  }
}
